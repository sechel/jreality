package de.jreality.swing;

import java.awt.peer.FramePeer;

class FakeFramePeer5 extends FakeFramePeer implements FramePeer {

	FakeFramePeer5(JFakeFrame f) {
		super(f);
	}

}
