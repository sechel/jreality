package de.jreality.scene.event;

import de.jreality.scene.AudioSource;

public class AudioEvent extends SceneEvent {
	public AudioEvent(AudioSource source) {
		super(source);
	}
}
