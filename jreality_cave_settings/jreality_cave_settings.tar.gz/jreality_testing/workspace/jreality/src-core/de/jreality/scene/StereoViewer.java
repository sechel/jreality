package de.jreality.scene;

public interface StereoViewer extends Viewer {

	public int getStereoType();
	public void setStereoType(int type);
}
